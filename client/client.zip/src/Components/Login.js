import React, { useState } from 'react'
import axios from "axios";
import { useHistory } from "react-router-dom";

const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [fldata, setFldata] = useState([]);
    let history = useHistory();

    const fetch = async() => {
        console.log("FETCH HERE")
        const response = await axios.get(`/students/${email}`)
        console.log("This is respons",response.data)
        setFldata(response.data)
        console.log(fldata)
        // .then((res)=>{
        //     console.log("Response",res.data)
        //     setFldata(res.data)
        // })
        // .catch((error)=>console.log(error))

    }

    const onlogin = (e) => {
        e.preventDefault();
        console.log(email,password)
        fetch()
        
        // if(email === fldata.email && password === fldata.password){
        //     alert("Login Successfull")
        // }
        // else{
        //     alert("Something went wrong!")
        // }
        
        // setEmail("");
        // setPassword("");
        
    }



    return (
        <div>
            <div className="container my-3">
            <h1>Login Here!</h1>
            <form onSubmit={onlogin}>
            <div className="form-group">
                <label htmlFor="exampleInputEmail1">Email Address</label>
                <input type="email" className="form-control" value={email} name="email" onChange={(e)=>setEmail(e.target.value)} placeholder="Enter email"/>
            </div>
            <div className="form-group">
                <label htmlFor="exampleInputPassword1">Password</label>
                <input type="password" className="form-control" value={password} onChange={(e)=>{setPassword(e.target.value)}} placeholder="Password" autoComplete="on"/>
            </div>
            <button type="submit" className="btn btn-primary my-3">Login</button>
            </form>
        </div>
        </div>
    )
}

export default Login
